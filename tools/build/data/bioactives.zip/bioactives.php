<?php

declare(strict_types=1);

return [

    [
        'id' => 'DF001',
        'name' => 'Beta-glucan',
        'canonicalName' => 'beta-glucan',
        'aliases' => [
            'β-glucan'
        ],
        'category' => 'Dietary Fibre',
        'subcategory' => 'Soluble Fibre',

        'plainEnglish' =>
            'A natural soluble fibre found mainly in oats and barley that supports heart, digestive and metabolic health.',

        'primaryAction' =>
            'Supports healthy cholesterol levels, blood glucose regulation and digestive health.',

        'description' =>
            'Beta-glucan is a soluble dietary fibre found primarily in oats and barley. It forms a gel-like substance within the digestive tract, slowing digestion and helping reduce LDL cholesterol while supporting healthy blood glucose regulation. It also acts as a fermentable fibre, encouraging production of beneficial short-chain fatty acids by the gut microbiome.',

        'scientificSummary' =>
            'Mixed-linkage β-(1→3)(1→4)-D-glucan that increases intestinal viscosity, reduces bile acid reabsorption, attenuates postprandial glycaemic response and is fermented to produce short-chain fatty acids including butyrate.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'oats',
            'barley',
            'cholesterol',
            'heart',
            'blood sugar',
            'gut',
            'satiety'
        ]
    ],

    [
        'id' => 'DF002',
        'name' => 'Pectin',
        'canonicalName' => 'pectin',
        'aliases' => [],
        'category' => 'Dietary Fibre',
        'subcategory' => 'Soluble Fibre',

        'plainEnglish' =>
            'A fruit fibre that helps support healthy digestion, beneficial gut bacteria and cholesterol balance.',

        'primaryAction' =>
            'Supports the gut microbiome and healthy cholesterol metabolism.',

        'description' =>
            'Pectin is abundant in apples, citrus fruits and many berries. It functions as a fermentable soluble fibre, helping beneficial intestinal bacteria thrive while also slowing digestion and contributing to healthy blood lipid levels.',

        'scientificSummary' =>
            'Complex heteropolysaccharide rich in galacturonic acid residues that undergoes microbial fermentation within the colon, promoting short-chain fatty acid production and supporting lipid metabolism.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'apple',
            'citrus',
            'berries',
            'gut',
            'microbiome',
            'cholesterol',
            'soluble fibre'
        ]
    ],

    [
        'id' => 'DF003',
        'name' => 'Inulin',
        'canonicalName' => 'inulin',
        'aliases' => [],
        'category' => 'Dietary Fibre',
        'subcategory' => 'Prebiotic Fibre',

        'plainEnglish' =>
            'A natural prebiotic fibre that feeds beneficial gut bacteria and supports digestive wellbeing.',

        'primaryAction' =>
            'Promotes growth of beneficial gut bacteria and production of short-chain fatty acids.',

        'description' =>
            'Inulin occurs naturally in chicory root, onions, garlic, leeks and Jerusalem artichokes. It selectively feeds beneficial bacteria including Bifidobacteria, supporting digestive comfort and overall metabolic health.',

        'scientificSummary' =>
            'Fructan polysaccharide resistant to digestion in the upper gastrointestinal tract that selectively stimulates beneficial intestinal microbiota and enhances microbial production of short-chain fatty acids.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'prebiotic',
            'gut',
            'microbiome',
            'garlic',
            'onion',
            'chicory',
            'digestion'
        ]
    ],

    [
        'id' => 'DF004',
        'name' => 'Resistant Starch',
        'canonicalName' => 'resistant starch',
        'aliases' => [],
        'category' => 'Dietary Fibre',
        'subcategory' => 'Fermentable Fibre',

        'plainEnglish' =>
            'A special form of starch that behaves like fibre and supports digestive and metabolic health.',

        'primaryAction' =>
            'Supports gut health, insulin sensitivity and healthy glucose metabolism.',

        'description' =>
            'Resistant starch escapes digestion in the small intestine and is fermented within the large intestine. This process supports beneficial bacteria and increases production of butyrate, an important energy source for colon cells.',

        'scientificSummary' =>
            'Poorly digestible starch fraction that undergoes colonic fermentation to generate butyrate and other short-chain fatty acids, improving gut barrier function and glycaemic regulation.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'butyrate',
            'gut',
            'microbiome',
            'blood sugar',
            'beans',
            'potatoes',
            'whole grains'
        ]
    ],

    [
        'id' => 'DF005',
        'name' => 'Arabinoxylan',
        'canonicalName' => 'arabinoxylan',
        'aliases' => [],
        'category' => 'Dietary Fibre',
        'subcategory' => 'Cereal Fibre',

        'plainEnglish' =>
            'A wholegrain fibre that supports beneficial gut bacteria and healthy glucose metabolism.',

        'primaryAction' =>
            'Supports the gut microbiome and contributes to metabolic health.',

        'description' =>
            'Arabinoxylan is a major structural fibre present in wheat, rye and other cereal grains. It has prebiotic properties and contributes to improved digestive and metabolic function through microbial fermentation.',

        'scientificSummary' =>
            'Non-starch polysaccharide composed primarily of arabinose and xylose residues that undergoes microbial fermentation, supporting microbiota diversity and production of beneficial metabolites.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 4,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'whole grains',
            'wheat',
            'rye',
            'microbiome',
            'prebiotic',
            'gut'
        ]
    ],
        [
        'id' => 'DF006',
        'name' => 'Cellulose',
        'canonicalName' => 'cellulose',
        'aliases' => [],
        'category' => 'Dietary Fibre',
        'subcategory' => 'Insoluble Fibre',

        'plainEnglish' =>
            'An insoluble plant fibre that supports healthy digestion and regular bowel function.',

        'primaryAction' =>
            'Promotes bowel regularity and healthy digestive transit.',

        'description' =>
            'Cellulose is the most abundant structural fibre found in plants. Although it is not significantly fermented by gut bacteria, it provides bulk within the digestive tract, helping maintain regular bowel movements and supporting overall digestive health.',

        'scientificSummary' =>
            'Linear β-(1→4)-linked glucose polysaccharide forming the primary structural component of plant cell walls. It increases faecal bulk and accelerates intestinal transit with minimal microbial fermentation.',

        'evidence' => 'High',
        'clinicalImportance' => 4,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'insoluble fibre',
            'bowel',
            'regularity',
            'digestion',
            'vegetables',
            'whole grains',
            'plant cell walls'
        ]
    ],

    [
        'id' => 'DF007',
        'name' => 'Hemicellulose',
        'canonicalName' => 'hemicellulose',
        'aliases' => [],
        'category' => 'Dietary Fibre',
        'subcategory' => 'Mixed Fibre',

        'plainEnglish' =>
            'A naturally occurring plant fibre that supports digestive health and a healthy gut microbiome.',

        'primaryAction' =>
            'Supports digestive function through both bulking and fermentation.',

        'description' =>
            'Hemicellulose is a diverse group of plant cell wall polysaccharides present in cereals, legumes and vegetables. Depending on its composition, it contributes both insoluble fibre and fermentable substrates that support beneficial intestinal bacteria.',

        'scientificSummary' =>
            'Heterogeneous group of non-cellulosic polysaccharides including xylans, mannans and glucans that contribute to stool bulk while partially supporting microbial fermentation and short-chain fatty acid production.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 4,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'whole grains',
            'vegetables',
            'legumes',
            'gut',
            'microbiome',
            'fibre'
        ]
    ],

    [
        'id' => 'DF008',
        'name' => 'Lignin',
        'canonicalName' => 'lignin',
        'aliases' => [],
        'category' => 'Dietary Fibre',
        'subcategory' => 'Insoluble Fibre',

        'plainEnglish' =>
            'A structural plant compound that contributes to healthy bowel function and digestive wellbeing.',

        'primaryAction' =>
            'Provides stool bulk and supports healthy intestinal transit.',

        'description' =>
            'Lignin is a complex structural polymer found in mature vegetables, seeds and whole grains. Although not fermentable like other fibres, it contributes significantly to stool bulk and assists efficient movement through the digestive tract.',

        'scientificSummary' =>
            'Highly cross-linked phenolic polymer incorporated into plant secondary cell walls. Resistant to human digestion and microbial degradation, contributing primarily to faecal bulk and intestinal transit.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 3,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'insoluble fibre',
            'bowel',
            'vegetables',
            'seeds',
            'whole grains',
            'digestion'
        ]
    ],

    [
        'id' => 'DF009',
        'name' => 'Fructooligosaccharides',
        'canonicalName' => 'fructooligosaccharides',
        'aliases' => [
            'FOS'
        ],
        'category' => 'Dietary Fibre',
        'subcategory' => 'Prebiotic Fibre',

        'plainEnglish' =>
            'Short-chain prebiotic fibres that nourish beneficial gut bacteria and support digestive health.',

        'primaryAction' =>
            'Selectively feeds beneficial intestinal bacteria.',

        'description' =>
            'Fructooligosaccharides, commonly known as FOS, occur naturally in onions, garlic, bananas and chicory root. They are readily fermented by beneficial gut bacteria, promoting microbiome diversity and digestive resilience.',

        'scientificSummary' =>
            'Short-chain fructans resistant to digestion in the upper gastrointestinal tract that selectively stimulate beneficial intestinal microbiota, particularly Bifidobacterium species, increasing production of short-chain fatty acids.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'FOS',
            'prebiotic',
            'gut',
            'microbiome',
            'banana',
            'garlic',
            'onion',
            'chicory'
        ]
    ],

    [
        'id' => 'DF010',
        'name' => 'Galactooligosaccharides',
        'canonicalName' => 'galactooligosaccharides',
        'aliases' => [
            'GOS'
        ],
        'category' => 'Dietary Fibre',
        'subcategory' => 'Prebiotic Fibre',

        'plainEnglish' =>
            'Prebiotic fibres that support beneficial gut bacteria, digestive health and immune function.',

        'primaryAction' =>
            'Encourages growth of beneficial gut bacteria and supports intestinal resilience.',

        'description' =>
            'Galactooligosaccharides, commonly abbreviated to GOS, are selectively fermented by beneficial intestinal bacteria. They are widely studied for their role in supporting digestive comfort, microbiome diversity and normal immune function.',

        'scientificSummary' =>
            'Galactose-containing oligosaccharides resistant to digestion in the upper gastrointestinal tract that selectively enhance populations of beneficial intestinal microbiota while increasing production of short-chain fatty acids.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'GOS',
            'prebiotic',
            'gut',
            'microbiome',
            'immune',
            'digestion',
            'short-chain fatty acids'
        ]
    ],
       [
        'id' => 'PP001',
        'name' => 'Anthocyanins',
        'canonicalName' => 'anthocyanins',
        'aliases' => [],
        'category' => 'Polyphenols',
        'subcategory' => 'Flavonoids',

        'plainEnglish' =>
            'Natural blue, purple and red plant pigments that help support heart, brain and blood vessel health.',

        'primaryAction' =>
            'Supports vascular function and helps protect cells from oxidative stress.',

        'description' =>
            'Anthocyanins are responsible for the deep red, blue and purple colours of berries, cherries, red cabbage and similar fruits and vegetables. They are among the most extensively studied plant polyphenols and are associated with cardiovascular, cognitive and metabolic health.',

        'scientificSummary' =>
            'Water-soluble flavonoid pigments with potent antioxidant and cell-signalling activity that influence endothelial function, inflammatory pathways and nitric oxide bioavailability.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'berries',
            'blueberries',
            'blackberries',
            'raspberries',
            'vascular',
            'heart',
            'brain',
            'antioxidant'
        ]
    ],

    [
        'id' => 'PP002',
        'name' => 'Quercetin',
        'canonicalName' => 'quercetin',
        'aliases' => [],
        'category' => 'Polyphenols',
        'subcategory' => 'Flavonols',

        'plainEnglish' =>
            'A widely distributed plant flavonoid that supports healthy inflammation responses and cardiovascular health.',

        'primaryAction' =>
            'Supports healthy inflammatory balance and antioxidant protection.',

        'description' =>
            'Quercetin occurs naturally in onions, apples, kale, berries and many other plant foods. It is recognised for supporting antioxidant defences while contributing to cardiovascular and immune health.',

        'scientificSummary' =>
            'Polyhydroxylated flavonol exhibiting antioxidant, anti-inflammatory and endothelial-supportive properties through modulation of NF-κB, Nrf2 and nitric oxide pathways.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'onions',
            'apples',
            'kale',
            'berries',
            'heart',
            'immune',
            'antioxidant'
        ]
    ],

    [
        'id' => 'PP003',
        'name' => 'Catechins',
        'canonicalName' => 'catechins',
        'aliases' => [],
        'category' => 'Polyphenols',
        'subcategory' => 'Flavanols',

        'plainEnglish' =>
            'Natural tea and cocoa compounds that support cardiovascular health and antioxidant protection.',

        'primaryAction' =>
            'Supports healthy blood vessels and antioxidant defence.',

        'description' =>
            'Catechins are abundant in green tea, cocoa and certain fruits. They contribute to vascular function, healthy blood flow and protection against oxidative stress.',

        'scientificSummary' =>
            'Flavan-3-ol polyphenols that influence endothelial nitric oxide synthesis, oxidative stress signalling and vascular homeostasis.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'green tea',
            'tea',
            'cocoa',
            'vascular',
            'heart',
            'antioxidant'
        ]
    ],

    [
        'id' => 'PP004',
        'name' => 'Epicatechin',
        'canonicalName' => 'epicatechin',
        'aliases' => [],
        'category' => 'Polyphenols',
        'subcategory' => 'Flavanols',

        'plainEnglish' =>
            'A cocoa and tea flavanol associated with healthy circulation and muscle function.',

        'primaryAction' =>
            'Supports vascular function and nitric oxide production.',

        'description' =>
            'Epicatechin is found in cocoa, tea and some berries. It contributes to healthy blood vessel function and has been investigated for supporting cardiovascular performance and healthy ageing.',

        'scientificSummary' =>
            'Bioactive flavanol that enhances endothelial nitric oxide synthesis, improves vascular responsiveness and modulates oxidative stress signalling.',

        'evidence' => 'High',
        'clinicalImportance' => 4,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'cocoa',
            'tea',
            'nitric oxide',
            'vascular',
            'circulation',
            'heart'
        ]
    ],

    [
        'id' => 'PP005',
        'name' => 'Kaempferol',
        'canonicalName' => 'kaempferol',
        'aliases' => [],
        'category' => 'Polyphenols',
        'subcategory' => 'Flavonols',

        'plainEnglish' =>
            'A flavonoid found in leafy greens and vegetables that supports healthy cellular protection.',

        'primaryAction' =>
            'Supports antioxidant defence and healthy inflammatory balance.',

        'description' =>
            'Kaempferol occurs naturally in kale, spinach, broccoli, beans and tea. Research suggests it contributes to cellular resilience through antioxidant and anti-inflammatory mechanisms.',

        'scientificSummary' =>
            'Polyphenolic flavonol that influences inflammatory signalling, antioxidant enzyme activity and cellular defence pathways through multiple molecular targets.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 4,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'kale',
            'spinach',
            'broccoli',
            'tea',
            'antioxidant',
            'cell protection'
        ]
    ], 
        [
        'id' => 'PP006',
        'name' => 'Resveratrol',
        'canonicalName' => 'resveratrol',
        'aliases' => [],
        'category' => 'Polyphenols',
        'subcategory' => 'Stilbenes',

        'plainEnglish' =>
            'A natural plant compound best known from grapes that supports healthy ageing and cardiovascular health.',

        'primaryAction' =>
            'Supports healthy cellular ageing and cardiovascular function.',

        'description' =>
            'Resveratrol occurs naturally in grapes, blueberries, peanuts and red wine. It has attracted considerable scientific interest because of its potential role in healthy ageing, cardiovascular protection and cellular resilience.',

        'scientificSummary' =>
            'Polyphenolic stilbene that modulates sirtuin signalling, mitochondrial function, oxidative stress and inflammatory pathways involved in cardiovascular and metabolic health.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 4,
        'maturity' => 'Growing',
        'status' => 'Active',

        'keywords' => [
            'grapes',
            'red wine',
            'blueberries',
            'peanuts',
            'healthy ageing',
            'heart',
            'cellular protection'
        ]
    ],

    [
        'id' => 'PP007',
        'name' => 'Ellagic Acid',
        'canonicalName' => 'ellagic acid',
        'aliases' => [],
        'category' => 'Polyphenols',
        'subcategory' => 'Phenolic Acids',

        'plainEnglish' =>
            'A berry-derived antioxidant that supports cellular protection and healthy inflammatory balance.',

        'primaryAction' =>
            'Supports antioxidant defence and healthy inflammatory responses.',

        'description' =>
            'Ellagic acid is abundant in raspberries, strawberries, blackberries and pomegranates. It contributes to antioxidant protection and supports normal cellular responses to oxidative stress.',

        'scientificSummary' =>
            'Polyphenolic dilactone produced from ellagitannins that exhibits antioxidant activity and is metabolised by the gut microbiota into bioactive urolithins.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 4,
        'maturity' => 'Growing',
        'status' => 'Active',

        'keywords' => [
            'raspberries',
            'strawberries',
            'blackberries',
            'pomegranate',
            'urolithins',
            'antioxidant'
        ]
    ],

    [
        'id' => 'PP008',
        'name' => 'Chlorogenic Acid',
        'canonicalName' => 'chlorogenic acid',
        'aliases' => [],
        'category' => 'Polyphenols',
        'subcategory' => 'Phenolic Acids',

        'plainEnglish' =>
            'A plant polyphenol that supports healthy glucose metabolism and antioxidant protection.',

        'primaryAction' =>
            'Supports healthy blood glucose regulation and antioxidant activity.',

        'description' =>
            'Chlorogenic acid occurs naturally in coffee, apples, pears and many berries. It has been widely studied for its role in glucose metabolism, antioxidant protection and cardiovascular wellbeing.',

        'scientificSummary' =>
            'Hydroxycinnamic acid ester that influences glucose absorption, hepatic glucose metabolism and oxidative stress through multiple biochemical pathways.',

        'evidence' => 'High',
        'clinicalImportance' => 4,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'coffee',
            'apple',
            'pear',
            'berries',
            'blood sugar',
            'antioxidant'
        ]
    ],

    [
        'id' => 'PP009',
        'name' => 'Hesperidin',
        'canonicalName' => 'hesperidin',
        'aliases' => [],
        'category' => 'Polyphenols',
        'subcategory' => 'Flavanones',

        'plainEnglish' =>
            'A citrus flavonoid that supports healthy circulation and blood vessel function.',

        'primaryAction' =>
            'Supports vascular health and healthy circulation.',

        'description' =>
            'Hesperidin is found primarily in oranges, lemons and other citrus fruits. Research suggests it contributes to healthy blood vessel function, circulation and antioxidant protection.',

        'scientificSummary' =>
            'Citrus flavanone glycoside that influences endothelial function, vascular tone and inflammatory signalling through antioxidant mechanisms.',

        'evidence' => 'High',
        'clinicalImportance' => 4,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'oranges',
            'lemons',
            'citrus',
            'vascular',
            'circulation',
            'heart'
        ]
    ],

    [
        'id' => 'PP010',
        'name' => 'Naringenin',
        'canonicalName' => 'naringenin',
        'aliases' => [],
        'category' => 'Polyphenols',
        'subcategory' => 'Flavanones',

        'plainEnglish' =>
            'A citrus polyphenol that supports metabolic health and antioxidant defence.',

        'primaryAction' =>
            'Supports healthy metabolic function and antioxidant protection.',

        'description' =>
            'Naringenin is abundant in grapefruit and other citrus fruits. It has been investigated for supporting healthy lipid metabolism, liver function and normal inflammatory responses.',

        'scientificSummary' =>
            'Flavanone aglycone that modulates lipid metabolism, oxidative stress, inflammatory pathways and hepatic cellular signalling.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 4,
        'maturity' => 'Growing',
        'status' => 'Active',

        'keywords' => [
            'grapefruit',
            'citrus',
            'liver',
            'lipids',
            'metabolism',
            'antioxidant'
        ]
    ],
        [
        'id' => 'OS001',
        'name' => 'Allicin',
        'canonicalName' => 'allicin',
        'aliases' => [],
        'category' => 'Sulphur Compounds',
        'subcategory' => 'Thiosulfinates',

        'plainEnglish' =>
            'A natural sulphur compound produced when fresh garlic is crushed that supports heart and immune health.',

        'primaryAction' =>
            'Supports cardiovascular health, healthy circulation and normal immune function.',

        'description' =>
            'Allicin is formed when garlic is chopped or crushed, activating the enzyme alliinase. It is responsible for many of garlic\'s recognised health benefits, including support for cardiovascular health, immune function and natural antimicrobial activity.',

        'scientificSummary' =>
            'A reactive sulphur-containing thiosulfinate produced enzymatically from alliin. It exhibits antimicrobial activity and influences nitric oxide signalling, oxidative stress and inflammatory pathways.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'garlic',
            'heart',
            'circulation',
            'immune',
            'antimicrobial',
            'nitric oxide'
        ]
    ],

    [
        'id' => 'OS002',
        'name' => 'Sulforaphane',
        'canonicalName' => 'sulforaphane',
        'aliases' => [],
        'category' => 'Sulphur Compounds',
        'subcategory' => 'Isothiocyanates',

        'plainEnglish' =>
            'A powerful plant compound from broccoli and related vegetables that activates the body\'s natural defence systems.',

        'primaryAction' =>
            'Supports detoxification pathways and antioxidant defence.',

        'description' =>
            'Sulforaphane is produced when broccoli, broccoli sprouts and related vegetables are chopped or chewed. It is one of the most extensively studied plant bioactives and is recognised for supporting antioxidant defence, cellular resilience and normal detoxification processes.',

        'scientificSummary' =>
            'A bioactive isothiocyanate generated from glucoraphanin through myrosinase activity. It activates Nrf2-mediated cytoprotective pathways and induces phase II detoxification enzymes.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'broccoli',
            'broccoli sprouts',
            'cruciferous vegetables',
            'Nrf2',
            'detoxification',
            'antioxidant'
        ]
    ],

    [
        'id' => 'OS003',
        'name' => 'Glucoraphanin',
        'canonicalName' => 'glucoraphanin',
        'aliases' => [],
        'category' => 'Sulphur Compounds',
        'subcategory' => 'Glucosinolates',

        'plainEnglish' =>
            'A naturally occurring compound in broccoli that is converted into sulforaphane during food preparation.',

        'primaryAction' =>
            'Provides the precursor required for sulforaphane formation.',

        'description' =>
            'Glucoraphanin is abundant in broccoli and especially broccoli sprouts. When plant tissue is chopped or chewed it comes into contact with the enzyme myrosinase, producing sulforaphane, one of the best studied bioactive compounds found in cruciferous vegetables.',

        'scientificSummary' =>
            'A glucosinolate precursor hydrolysed by myrosinase to produce sulforaphane. The efficiency of this conversion depends upon food preparation and the activity of intestinal microbiota.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'broccoli',
            'broccoli sprouts',
            'glucosinolates',
            'sulforaphane',
            'cruciferous vegetables'
        ]
    ],

    [
        'id' => 'OS004',
        'name' => 'Diallyl Sulphide',
        'canonicalName' => 'diallyl sulphide',
        'aliases' => [
            'Diallyl Sulfide'
        ],
        'category' => 'Sulphur Compounds',
        'subcategory' => 'Sulphides',

        'plainEnglish' =>
            'A garlic-derived sulphur compound that supports healthy detoxification and antioxidant protection.',

        'primaryAction' =>
            'Supports liver detoxification enzymes and antioxidant defence.',

        'description' =>
            'Diallyl sulphide is one of several sulphur-containing compounds naturally present in garlic. Research suggests it contributes to antioxidant protection while supporting normal liver detoxification pathways and cellular resilience.',

        'scientificSummary' =>
            'A lipid-soluble sulphur compound that modulates cytochrome P450 enzyme activity, glutathione metabolism and cellular antioxidant defence mechanisms.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 4,
        'maturity' => 'Growing',
        'status' => 'Active',

        'keywords' => [
            'garlic',
            'liver',
            'detoxification',
            'glutathione',
            'antioxidant'
        ]
    ],

    [
        'id' => 'OS005',
        'name' => 'S-Methyl Cysteine Sulfoxide',
        'canonicalName' => 's-methyl cysteine sulfoxide',
        'aliases' => [
            'SMCSO'
        ],
        'category' => 'Sulphur Compounds',
        'subcategory' => 'Sulfoxides',

        'plainEnglish' =>
            'A naturally occurring sulphur compound found in onions and brassica vegetables that supports healthy metabolism.',

        'primaryAction' =>
            'Supports antioxidant activity and healthy metabolic function.',

        'description' =>
            'S-Methyl Cysteine Sulfoxide occurs naturally in onions, cabbage and other brassica vegetables. Current evidence suggests it contributes to antioxidant protection and supports normal glucose and lipid metabolism.',

        'scientificSummary' =>
            'A sulphur-containing amino acid derivative present in Allium and Brassica species that exhibits antioxidant activity and may influence glucose and lipid metabolic pathways.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 4,
        'maturity' => 'Growing',
        'status' => 'Active',

        'keywords' => [
            'onion',
            'cabbage',
            'allium',
            'brassica',
            'metabolism',
            'antioxidant'
        ]
    ],
       [
        'id' => 'CA001',
        'name' => 'Lycopene',
        'canonicalName' => 'lycopene',
        'aliases' => [],
        'category' => 'Carotenoids',
        'subcategory' => 'Carotenes',

        'plainEnglish' =>
            'A bright red plant pigment found mainly in tomatoes that supports heart and prostate health.',

        'primaryAction' =>
            'Supports cardiovascular health and protects cells from oxidative stress.',

        'description' =>
            'Lycopene is the red carotenoid pigment responsible for the colour of tomatoes, watermelon and pink grapefruit. It is recognised for its antioxidant activity and has been extensively studied for supporting cardiovascular health and healthy ageing.',

        'scientificSummary' =>
            'An acyclic carotene with potent singlet oxygen quenching capacity that contributes to antioxidant defence and supports cardiovascular and prostate health through multiple cellular pathways.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'tomato',
            'watermelon',
            'pink grapefruit',
            'heart',
            'prostate',
            'antioxidant'
        ]
    ],

    [
        'id' => 'CA002',
        'name' => 'Lutein',
        'canonicalName' => 'lutein',
        'aliases' => [],
        'category' => 'Carotenoids',
        'subcategory' => 'Xanthophylls',

        'plainEnglish' =>
            'A yellow plant pigment that supports healthy vision and protects the eyes from oxidative stress.',

        'primaryAction' =>
            'Supports macular health and healthy vision.',

        'description' =>
            'Lutein is abundant in spinach, kale and other leafy green vegetables. It accumulates within the retina where it helps filter high-energy blue light while supporting long-term eye health.',

        'scientificSummary' =>
            'A dietary xanthophyll concentrated within the macula that filters short-wavelength light and provides antioxidant protection to retinal tissues.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'spinach',
            'kale',
            'vision',
            'eyes',
            'retina',
            'macula'
        ]
    ],

    [
        'id' => 'CA003',
        'name' => 'Zeaxanthin',
        'canonicalName' => 'zeaxanthin',
        'aliases' => [],
        'category' => 'Carotenoids',
        'subcategory' => 'Xanthophylls',

        'plainEnglish' =>
            'A carotenoid that works alongside lutein to support healthy eyesight and retinal protection.',

        'primaryAction' =>
            'Supports retinal protection and visual performance.',

        'description' =>
            'Zeaxanthin is found in maize, peppers and leafy green vegetables. Together with lutein it forms the macular pigments that help protect the retina from oxidative damage and excessive blue light exposure.',

        'scientificSummary' =>
            'A xanthophyll carotenoid concentrated within the macula that contributes to visual performance through blue-light filtration and antioxidant activity.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'eyes',
            'retina',
            'macula',
            'peppers',
            'maize',
            'vision'
        ]
    ],

    [
        'id' => 'CA004',
        'name' => 'Beta-carotene',
        'canonicalName' => 'beta-carotene',
        'aliases' => [
            'β-carotene'
        ],
        'category' => 'Carotenoids',
        'subcategory' => 'Carotenes',

        'plainEnglish' =>
            'An orange plant pigment that the body converts into vitamin A when needed.',

        'primaryAction' =>
            'Supports healthy vision, immunity and skin health.',

        'description' =>
            'Beta-carotene is abundant in carrots, sweet potatoes, pumpkin and leafy green vegetables. It acts as a precursor to vitamin A while also providing antioxidant protection.',

        'scientificSummary' =>
            'A provitamin A carotenoid that undergoes enzymatic cleavage to retinal while also functioning as an antioxidant within lipid environments.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'carrots',
            'pumpkin',
            'sweet potato',
            'vitamin A',
            'vision',
            'immune'
        ]
    ],

    [
        'id' => 'CA005',
        'name' => 'Alpha-carotene',
        'canonicalName' => 'alpha-carotene',
        'aliases' => [
            'α-carotene'
        ],
        'category' => 'Carotenoids',
        'subcategory' => 'Carotenes',

        'plainEnglish' =>
            'A naturally occurring carotenoid that supports antioxidant protection and vitamin A production.',

        'primaryAction' =>
            'Supports antioxidant protection and healthy vitamin A status.',

        'description' =>
            'Alpha-carotene is found in carrots, pumpkin and winter squash. Like beta-carotene it can contribute to vitamin A production while providing antioxidant activity.',

        'scientificSummary' =>
            'A provitamin A carotenoid with antioxidant properties that contributes to vitamin A metabolism and cellular protection.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 4,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'carrots',
            'pumpkin',
            'squash',
            'vitamin A',
            'antioxidant'
        ]
    ],

    [
        'id' => 'CA006',
        'name' => 'Astaxanthin',
        'canonicalName' => 'astaxanthin',
        'aliases' => [],
        'category' => 'Carotenoids',
        'subcategory' => 'Ketocarotenoids',

        'plainEnglish' =>
            'A deep red marine carotenoid recognised for its exceptionally strong antioxidant activity.',

        'primaryAction' =>
            'Provides antioxidant protection for cells and supports healthy ageing.',

        'description' =>
            'Astaxanthin is produced by microalgae and accumulates naturally in salmon, trout and shellfish. It is regarded as one of the most potent naturally occurring carotenoid antioxidants.',

        'scientificSummary' =>
            'A marine ketocarotenoid with exceptional antioxidant capacity that protects cell membranes and mitochondria from oxidative stress.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 4,
        'maturity' => 'Growing',
        'status' => 'Active',

        'keywords' => [
            'salmon',
            'trout',
            'shellfish',
            'marine',
            'antioxidant',
            'mitochondria'
        ]
    ], 
        [
        'id' => 'FA001',
        'name' => 'Alpha-Linolenic Acid',
        'canonicalName' => 'alpha-linolenic acid',
        'aliases' => [
            'ALA'
        ],
        'category' => 'Fatty Acids',
        'subcategory' => 'Omega-3',

        'plainEnglish' =>
            'An essential plant omega-3 fatty acid that supports heart, brain and overall health.',

        'primaryAction' =>
            'Supports cardiovascular health and provides the foundation for omega-3 metabolism.',

        'description' =>
            'Alpha-linolenic acid is an essential omega-3 fatty acid found in flaxseed, chia seeds, hemp seeds and walnuts. Although only a small proportion is converted into EPA and DHA, ALA contributes directly to cardiovascular health and healthy inflammatory balance.',

        'scientificSummary' =>
            'An essential eighteen-carbon omega-3 polyunsaturated fatty acid that serves as the dietary precursor to EPA and DHA while contributing independently to cardiovascular and metabolic health.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'ALA',
            'flaxseed',
            'chia',
            'walnuts',
            'hemp',
            'omega-3',
            'heart'
        ]
    ],

    [
        'id' => 'FA002',
        'name' => 'Eicosapentaenoic Acid',
        'canonicalName' => 'eicosapentaenoic acid',
        'aliases' => [
            'EPA'
        ],
        'category' => 'Fatty Acids',
        'subcategory' => 'Omega-3',

        'plainEnglish' =>
            'A marine omega-3 fatty acid that supports cardiovascular, brain and inflammatory health.',

        'primaryAction' =>
            'Supports healthy inflammatory balance and cardiovascular function.',

        'description' =>
            'EPA is found primarily in oily fish and marine algae. It plays an important role in maintaining healthy inflammatory responses and supporting cardiovascular wellbeing.',

        'scientificSummary' =>
            'A long-chain marine omega-3 fatty acid incorporated into cell membranes where it influences eicosanoid synthesis, inflammatory signalling and cardiovascular physiology.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'EPA',
            'fish',
            'salmon',
            'mackerel',
            'sardines',
            'omega-3',
            'heart'
        ]
    ],

    [
        'id' => 'FA003',
        'name' => 'Docosahexaenoic Acid',
        'canonicalName' => 'docosahexaenoic acid',
        'aliases' => [
            'DHA'
        ],
        'category' => 'Fatty Acids',
        'subcategory' => 'Omega-3',

        'plainEnglish' =>
            'A marine omega-3 fatty acid that is an important structural component of the brain and retina.',

        'primaryAction' =>
            'Supports normal brain function and healthy vision.',

        'description' =>
            'DHA is abundant in oily fish and marine algae. It is highly concentrated in the brain and retina where it contributes to healthy neurological function and visual development.',

        'scientificSummary' =>
            'A twenty-two-carbon marine omega-3 fatty acid that contributes to neuronal membrane fluidity, retinal function and neurodevelopment.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'DHA',
            'brain',
            'vision',
            'retina',
            'fish',
            'omega-3'
        ]
    ],

    [
        'id' => 'FA004',
        'name' => 'Oleic Acid',
        'canonicalName' => 'oleic acid',
        'aliases' => [],
        'category' => 'Fatty Acids',
        'subcategory' => 'Monounsaturated',

        'plainEnglish' =>
            'The principal healthy fat found in olive oil, avocados and many nuts.',

        'primaryAction' =>
            'Supports cardiovascular health and healthy cholesterol balance.',

        'description' =>
            'Oleic acid is the predominant monounsaturated fatty acid in olive oil, avocados and almonds. It forms a major part of Mediterranean dietary patterns associated with cardiovascular health.',

        'scientificSummary' =>
            'A monounsaturated omega-9 fatty acid that supports membrane integrity, lipid metabolism and healthy cardiovascular physiology.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'olive oil',
            'avocado',
            'almonds',
            'omega-9',
            'heart',
            'cholesterol'
        ]
    ],

    [
        'id' => 'FA005',
        'name' => 'Linoleic Acid',
        'canonicalName' => 'linoleic acid',
        'aliases' => [
            'LA'
        ],
        'category' => 'Fatty Acids',
        'subcategory' => 'Omega-6',

        'plainEnglish' =>
            'An essential omega-6 fatty acid required for healthy cell membranes and normal growth.',

        'primaryAction' =>
            'Supports healthy cell membranes and normal physiological function.',

        'description' =>
            'Linoleic acid is an essential omega-6 fatty acid found in seeds, nuts and vegetable oils. It is required for normal growth, skin integrity and healthy cellular function.',

        'scientificSummary' =>
            'An essential omega-6 polyunsaturated fatty acid that serves as a precursor for arachidonic acid and contributes to membrane phospholipid structure and signalling.',

        'evidence' => 'High',
        'clinicalImportance' => 4,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'LA',
            'sunflower seeds',
            'pumpkin seeds',
            'nuts',
            'omega-6',
            'cell membranes'
        ]
    ],
        [
        'id' => 'TP001',
        'name' => 'Limonene',
        'canonicalName' => 'limonene',
        'aliases' => [
            'D-Limonene'
        ],
        'category' => 'Terpenes',
        'subcategory' => 'Monoterpenes',

        'plainEnglish' =>
            'A citrus terpene that supports healthy digestion and antioxidant defence.',

        'primaryAction' =>
            'Supports digestive health and cellular antioxidant protection.',

        'description' =>
            'Limonene is the principal terpene found in the peel of oranges, lemons and other citrus fruits. It contributes to the characteristic citrus aroma while supporting digestive function, antioxidant defence and healthy inflammatory balance.',

        'scientificSummary' =>
            'A monocyclic monoterpene abundant in citrus peel that exhibits antioxidant, anti-inflammatory and gastroprotective activity through multiple cellular signalling pathways.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 4,
        'maturity' => 'Growing',
        'status' => 'Active',

        'keywords' => [
            'orange',
            'lemon',
            'citrus',
            'digestion',
            'antioxidant',
            'terpene'
        ]
    ],

    [
        'id' => 'TP002',
        'name' => 'Menthol',
        'canonicalName' => 'menthol',
        'aliases' => [],
        'category' => 'Terpenes',
        'subcategory' => 'Monoterpenes',

        'plainEnglish' =>
            'A cooling mint compound that supports digestive comfort and respiratory wellbeing.',

        'primaryAction' =>
            'Supports digestive comfort and healthy respiratory function.',

        'description' =>
            'Menthol is the principal terpene alcohol found in peppermint and related mint species. It is widely recognised for supporting digestive comfort, normal respiratory function and sensory cooling.',

        'scientificSummary' =>
            'A cyclic monoterpene alcohol that activates TRPM8 receptors while contributing to gastrointestinal comfort and respiratory function.',

        'evidence' => 'High',
        'clinicalImportance' => 4,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'peppermint',
            'mint',
            'digestion',
            'respiratory',
            'TRPM8'
        ]
    ],

    [
        'id' => 'TP003',
        'name' => 'Thymol',
        'canonicalName' => 'thymol',
        'aliases' => [],
        'category' => 'Terpenes',
        'subcategory' => 'Monoterpenes',

        'plainEnglish' =>
            'A thyme-derived terpene that supports normal immune function and antioxidant defence.',

        'primaryAction' =>
            'Supports healthy immune function and antioxidant protection.',

        'description' =>
            'Thymol occurs naturally in thyme and oregano. It has been extensively studied for its antimicrobial properties and its contribution to healthy immune and respiratory function.',

        'scientificSummary' =>
            'A phenolic monoterpene exhibiting antimicrobial, antioxidant and anti-inflammatory activity through membrane interactions and cellular signalling.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 4,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'thyme',
            'oregano',
            'immune',
            'antioxidant',
            'antimicrobial'
        ]
    ],

    [
        'id' => 'TP004',
        'name' => 'Carvacrol',
        'canonicalName' => 'carvacrol',
        'aliases' => [],
        'category' => 'Terpenes',
        'subcategory' => 'Monoterpenes',

        'plainEnglish' =>
            'A naturally occurring oregano compound that supports healthy microbial balance and antioxidant defence.',

        'primaryAction' =>
            'Supports healthy microbial balance and cellular protection.',

        'description' =>
            'Carvacrol is abundant in oregano and thyme. Research suggests it contributes to healthy microbial balance while supporting antioxidant activity and normal inflammatory responses.',

        'scientificSummary' =>
            'A phenolic monoterpene that exhibits antimicrobial, antioxidant and anti-inflammatory properties through modulation of microbial membranes and cellular signalling pathways.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 4,
        'maturity' => 'Growing',
        'status' => 'Active',

        'keywords' => [
            'oregano',
            'thyme',
            'antimicrobial',
            'antioxidant',
            'microbiome'
        ]
    ],
        [
        'id' => 'PS001',
        'name' => 'Beta-sitosterol',
        'canonicalName' => 'beta-sitosterol',
        'aliases' => [
            'β-sitosterol'
        ],
        'category' => 'Phytosterols',
        'subcategory' => 'Sterols',

        'plainEnglish' =>
            'A naturally occurring plant sterol that helps support healthy cholesterol levels.',

        'primaryAction' =>
            'Supports healthy cholesterol metabolism by reducing cholesterol absorption.',

        'description' =>
            'Beta-sitosterol is the most abundant phytosterol found in nuts, seeds, legumes and vegetable oils. It competes with dietary cholesterol during absorption within the intestine, helping maintain healthy blood cholesterol levels.',

        'scientificSummary' =>
            'A plant-derived phytosterol structurally similar to cholesterol that competitively inhibits intestinal cholesterol absorption while supporting healthy lipid metabolism.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'nuts',
            'seeds',
            'cholesterol',
            'heart',
            'plant sterols',
            'lipids'
        ]
    ],

    [
        'id' => 'PS002',
        'name' => 'Campesterol',
        'canonicalName' => 'campesterol',
        'aliases' => [],
        'category' => 'Phytosterols',
        'subcategory' => 'Sterols',

        'plainEnglish' =>
            'A naturally occurring plant sterol that contributes to healthy cholesterol balance.',

        'primaryAction' =>
            'Supports healthy cholesterol absorption and cardiovascular health.',

        'description' =>
            'Campesterol occurs naturally in vegetable oils, seeds, whole grains and legumes. Like other phytosterols it contributes to healthy cholesterol metabolism by reducing intestinal cholesterol absorption.',

        'scientificSummary' =>
            'A dietary phytosterol structurally related to cholesterol that contributes to cholesterol homeostasis through competitive inhibition of intestinal absorption.',

        'evidence' => 'High',
        'clinicalImportance' => 4,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'vegetable oils',
            'whole grains',
            'seeds',
            'heart',
            'cholesterol'
        ]
    ],

    [
        'id' => 'PS003',
        'name' => 'Stigmasterol',
        'canonicalName' => 'stigmasterol',
        'aliases' => [],
        'category' => 'Phytosterols',
        'subcategory' => 'Sterols',

        'plainEnglish' =>
            'A naturally occurring plant sterol found in legumes, seeds and vegetable oils that supports healthy cholesterol metabolism.',

        'primaryAction' =>
            'Supports healthy cholesterol metabolism and cellular function.',

        'description' =>
            'Stigmasterol is naturally present in legumes, seeds, nuts and many vegetable oils. Research suggests it contributes to healthy lipid metabolism while also supporting normal cell membrane function.',

        'scientificSummary' =>
            'A naturally occurring phytosterol that contributes to cholesterol homeostasis and membrane structure through interactions with lipid metabolism.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 4,
        'maturity' => 'Growing',
        'status' => 'Active',

        'keywords' => [
            'legumes',
            'seeds',
            'nuts',
            'vegetable oils',
            'cholesterol',
            'lipids'
        ]
    ],
        [
        'id' => 'FC001',
        'name' => 'Curcumin',
        'canonicalName' => 'curcumin',
        'aliases' => [],
        'category' => 'Functional Compounds',
        'subcategory' => 'Curcuminoids',

        'plainEnglish' =>
            'The principal active compound in turmeric that supports healthy inflammatory balance and antioxidant protection.',

        'primaryAction' =>
            'Supports healthy inflammatory responses and antioxidant defence.',

        'description' =>
            'Curcumin is the principal bioactive compound found in turmeric. It has been extensively researched for supporting healthy inflammatory responses, antioxidant activity and cellular resilience. Its absorption is naturally low but can be enhanced when consumed with black pepper.',

        'scientificSummary' =>
            'A polyphenolic diarylheptanoid that modulates NF-kB, Nrf2 and multiple inflammatory signalling pathways while exhibiting antioxidant and cytoprotective activity.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'turmeric',
            'anti-inflammatory',
            'antioxidant',
            'NF-kB',
            'Nrf2'
        ]
    ],

    [
        'id' => 'FC002',
        'name' => 'Piperine',
        'canonicalName' => 'piperine',
        'aliases' => [],
        'category' => 'Functional Compounds',
        'subcategory' => 'Alkaloids',

        'plainEnglish' =>
            'The natural compound in black pepper that improves absorption of several nutrients.',

        'primaryAction' =>
            'Enhances the absorption of selected nutrients and bioactive compounds.',

        'description' =>
            'Piperine is the principal pungent alkaloid found in black pepper. It is widely recognised for enhancing the bioavailability of compounds including curcumin by influencing intestinal absorption and metabolism.',

        'scientificSummary' =>
            'A piperidine alkaloid that increases bioavailability through modulation of intestinal permeability and inhibition of selected drug-metabolising enzymes.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'black pepper',
            'bioavailability',
            'absorption',
            'curcumin'
        ]
    ],

    [
        'id' => 'FC003',
        'name' => 'Capsaicin',
        'canonicalName' => 'capsaicin',
        'aliases' => [],
        'category' => 'Functional Compounds',
        'subcategory' => 'Capsaicinoids',

        'plainEnglish' =>
            'The natural compound responsible for the heat of chilli peppers that supports healthy metabolism.',

        'primaryAction' =>
            'Supports healthy metabolism and energy expenditure.',

        'description' =>
            'Capsaicin is found in chilli peppers and is responsible for their characteristic heat. Research suggests it contributes to healthy metabolic function, thermogenesis and appetite regulation.',

        'scientificSummary' =>
            'A vanilloid compound that activates TRPV1 receptors, influencing thermogenesis, metabolism and nociceptive signalling.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 4,
        'maturity' => 'Growing',
        'status' => 'Active',

        'keywords' => [
            'chilli',
            'TRPV1',
            'metabolism',
            'thermogenesis'
        ]
    ],

    [
        'id' => 'FC004',
        'name' => 'Gingerol',
        'canonicalName' => 'gingerol',
        'aliases' => [
            '6-Gingerol'
        ],
        'category' => 'Functional Compounds',
        'subcategory' => 'Phenolic Ketones',

        'plainEnglish' =>
            'The principal active compound in fresh ginger that supports digestion and healthy inflammatory balance.',

        'primaryAction' =>
            'Supports digestive comfort and healthy inflammatory responses.',

        'description' =>
            'Gingerol is the major bioactive compound in fresh ginger. It contributes to digestive comfort while supporting antioxidant activity and normal inflammatory responses.',

        'scientificSummary' =>
            'A phenolic ketone that influences inflammatory signalling, gastrointestinal motility and antioxidant defence pathways.',

        'evidence' => 'High',
        'clinicalImportance' => 4,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'ginger',
            'digestion',
            'anti-inflammatory',
            'antioxidant'
        ]
    ],

    [
        'id' => 'FC005',
        'name' => 'Shogaol',
        'canonicalName' => 'shogaol',
        'aliases' => [
            '6-Shogaol'
        ],
        'category' => 'Functional Compounds',
        'subcategory' => 'Phenolic Ketones',

        'plainEnglish' =>
            'A bioactive compound formed when ginger is dried or heated that supports antioxidant and inflammatory balance.',

        'primaryAction' =>
            'Supports antioxidant activity and healthy inflammatory responses.',

        'description' =>
            'Shogaol is formed from gingerol during drying or cooking of ginger. It exhibits potent biological activity and contributes to many of the recognised health properties of dried ginger.',

        'scientificSummary' =>
            'A dehydration product of gingerol exhibiting potent antioxidant, anti-inflammatory and neuroprotective activity through modulation of multiple signalling pathways.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 4,
        'maturity' => 'Growing',
        'status' => 'Active',

        'keywords' => [
            'dried ginger',
            'ginger',
            'antioxidant',
            'anti-inflammatory'
        ]
    ],
        [
        'id' => 'FC006',
        'name' => 'Cinnamaldehyde',
        'canonicalName' => 'cinnamaldehyde',
        'aliases' => [],
        'category' => 'Functional Compounds',
        'subcategory' => 'Phenylpropanoids',

        'plainEnglish' =>
            'The principal active compound in cinnamon that supports healthy blood glucose metabolism and antioxidant protection.',

        'primaryAction' =>
            'Supports healthy glucose metabolism and antioxidant defence.',

        'description' =>
            'Cinnamaldehyde is the compound responsible for the distinctive flavour and aroma of cinnamon. Research suggests it contributes to healthy glucose metabolism, antioxidant activity and normal inflammatory responses.',

        'scientificSummary' =>
            'A phenylpropanoid aldehyde that modulates glucose metabolism, antioxidant defence and inflammatory signalling through multiple molecular pathways.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 4,
        'maturity' => 'Growing',
        'status' => 'Active',

        'keywords' => [
            'cinnamon',
            'blood sugar',
            'glucose',
            'antioxidant',
            'phenylpropanoids'
        ]
    ],

    [
        'id' => 'FC007',
        'name' => 'Melatonin',
        'canonicalName' => 'melatonin',
        'aliases' => [],
        'category' => 'Functional Compounds',
        'subcategory' => 'Indoleamines',

        'plainEnglish' =>
            'A naturally occurring compound found in small amounts in certain foods that supports healthy sleep regulation.',

        'primaryAction' =>
            'Supports healthy sleep and normal circadian rhythm.',

        'description' =>
            'Melatonin is best known as the hormone regulating the sleep-wake cycle, but it also occurs naturally in foods such as tart cherries, walnuts and some grains. Dietary melatonin contributes to antioxidant activity and healthy circadian regulation.',

        'scientificSummary' =>
            'An indoleamine synthesised from tryptophan that regulates circadian rhythms while exhibiting antioxidant and mitochondrial protective properties.',

        'evidence' => 'Moderate',
        'clinicalImportance' => 3,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'sleep',
            'circadian rhythm',
            'tart cherries',
            'walnuts',
            'antioxidant'
        ]
    ],

    [
        'id' => 'FC008',
        'name' => 'Coenzyme Q10',
        'canonicalName' => 'coenzyme q10',
        'aliases' => [
            'CoQ10',
            'Ubiquinone'
        ],
        'category' => 'Functional Compounds',
        'subcategory' => 'Quinones',

        'plainEnglish' =>
            'A naturally occurring compound involved in cellular energy production and antioxidant defence.',

        'primaryAction' =>
            'Supports cellular energy production and antioxidant protection.',

        'description' =>
            'Coenzyme Q10 is present in all human cells and is also obtained from foods including oily fish, meat and nuts. It plays a central role in mitochondrial energy production while protecting cells from oxidative damage.',

        'scientificSummary' =>
            'A lipid-soluble benzoquinone that functions within the mitochondrial electron transport chain while protecting membrane lipids from oxidative stress.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'CoQ10',
            'mitochondria',
            'energy',
            'heart',
            'antioxidant'
        ]
    ],

    [
        'id' => 'FC009',
        'name' => 'Taurine',
        'canonicalName' => 'taurine',
        'aliases' => [],
        'category' => 'Functional Compounds',
        'subcategory' => 'Amino Acid Derivatives',

        'plainEnglish' =>
            'A sulphur-containing amino acid derivative that supports cardiovascular, muscular and neurological function.',

        'primaryAction' =>
            'Supports cardiovascular function and normal cellular hydration.',

        'description' =>
            'Taurine is naturally present in seafood, meat and dairy products. It contributes to cardiovascular health, muscle function, nervous system activity and cellular fluid balance.',

        'scientificSummary' =>
            'A sulphur-containing amino acid derivative involved in osmoregulation, bile acid conjugation, calcium signalling and mitochondrial function.',

        'evidence' => 'High',
        'clinicalImportance' => 4,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'taurine',
            'heart',
            'muscle',
            'brain',
            'hydration',
            'mitochondria'
        ]
    ],

    [
        'id' => 'FC010',
        'name' => 'Creatine',
        'canonicalName' => 'creatine',
        'aliases' => [],
        'category' => 'Functional Compounds',
        'subcategory' => 'Amino Acid Derivatives',

        'plainEnglish' =>
            'A naturally occurring compound that supports muscular performance, brain function and cellular energy production.',

        'primaryAction' =>
            'Supports rapid energy production in muscles and the brain.',

        'description' =>
            'Creatine occurs naturally in meat and fish and is also synthesised by the human body. It plays an essential role in cellular energy production, particularly during periods of high energy demand such as muscular contraction and cognitive activity.',

        'scientificSummary' =>
            'A guanidino compound that forms phosphocreatine, providing rapid regeneration of ATP during periods of increased muscular and neurological energy demand.',

        'evidence' => 'High',
        'clinicalImportance' => 5,
        'maturity' => 'Established',
        'status' => 'Active',

        'keywords' => [
            'creatine',
            'ATP',
            'muscle',
            'brain',
            'energy',
            'performance'
        ]
    ]
    
];
